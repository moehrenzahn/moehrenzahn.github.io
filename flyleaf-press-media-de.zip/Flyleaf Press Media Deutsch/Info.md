# Flyleaf

https://moehrenzahn.de/de/project/flyleaf/

Von Max Melzer, flyleaf@moehrenzahn.de

## Beschreibung

Flyleaf ist eine „Read-Later“-App, die Artikel aus dem Web speichert und in einer liebevoll gestalteten Leseansicht präsentiert.

ARTIKEL AUS DEM INTERNET SPEICHERN
Mit dem Share Sheet kannst du von überall interessante Links in Flyleaf speichern. Es gibt auch ein einfaches Bookmarklet für maximale Flexibilität.

SPÄTER LESEN OHNE ABLENKUNGEN
Flyleaf speichert Webseiten und entfernt alles Unwichtige, wie Popups, Werbung und Tracker. So schonst du deine Privatsphäre und deinen Verstand.

WEBSEITEN WIE EINE ZEITSCHRIFT LESEN
Mit der Blätterfunktion kannst du Artikel in Flyleaf Seite für Seite lesen, anstatt immer vertikal zu scrollen.

LIES WIE DU WILLST
Flyleaf bietet zahlreiche Möglichkeiten, dein Leseerlebnis anzupassen, z. B. alternative Farbdesigns und tiefgreifende Typografieanpassungen.

ENTDECKE WAS DU ALS NÄCHSTES LESEN MÖCHTEST 
Wenn die Artikelliste wächst, kann man leicht den Überblick verlieren. Flyleaf hilft dir, immer was Neues in deiner Liste zu entdecken.

SYNCHRONISIERUNG MIT ICLOUD
Flyleaf nutzt iCloud, um Artikel und Lesefortschritt sicher zwischen deinen Geräten zu synchronisieren - ohne zusätzliche Accounts.

ORDNUNG HALTEN MIT SCHLAGWÖRTERN
Du kannst deine eigenen Schlagwörter zu Artikeln hinzufügen, um deine Bibliothek zu organisieren.

LIES WO IMMER DU BIST
Genieße die Vorteile von komplett nativen Apps für iPhone, iPad und macOS, liebevoll gestaltet von Indie-Entwickler Max Melzer.

LIES IM VOLLBILD 
Verbanne alle Ablenkungen und konzentriere dich ganz auf den Text, indem du den Vollbildmodus aktivierst. Über die intuitive Gestensteuerung bleiben alle Funktionen in Reichweite.

LADE ARTIKEL MIT EINEM FINGERTIPP VON ARCHIVE.TODAY 
Manchmal kommt es vor, dass ein Artikel in deiner Region nicht verfügbar ist oder ein Login erfordert. Mit Flyleaf kannst du viele dieser Artikel stattdessen mühelos aus einem Webarchiv abrufen.

AUTOMATISIERE AKTIONEN MIT SHORTCUTS UND SIRI
Flyleaf bietet Systemintegrationen, mit denen du z.B. über Siri Links hinzufügen kannst. Du kannst außerdem deine eigenen Kurzbefehle erstellen, um z.B. Artikel automatisch zu Verschlagworten.

Flyleaf kann kostenlos genutzt werden und bietet ein optionales Abo für erweiterte Funktionen wie Designs, Schlagwörter und die archive.today-Integration.

Datenschutzerklärung: https://moehrenzahn.de/de/project/flyleaf/privacy/
Nutzungsbedingungen: https://moehrenzahn.de/de/project/flyleaf/terms/
