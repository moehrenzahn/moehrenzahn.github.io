# Flyleaf

https://moehrenzahn.de/project/flyleaf/

By Max Melzer, flyleaf@moehrenzahn.de

## Description

Flyleaf is a “read-later” app that displays articles from the web in a meticulously designed reading view, without popups, ads or other distractions.

You can add articles from any app that has a share sheet, through a bookmarklet, or by manually entering the URL.

The distinguishing feature of Flyleaf is its unparalleled book-style pagination. You can read articles page by page instead of scrolling vertically.

Other features:

+ Fully native app for iPhone, iPad, and macOS
+ Sync across all your devices through iCloud
+ No accounts, ads or tracking. Our privacy policy is very short
+ Great typography with lots of customization options
+ Easily find RSS feeds of blogs and sites you like
+ Comprehensive support for Shortcuts actions

Flyleaf is free to use and offers an optional subscription for advanced features such as tagging articles.
