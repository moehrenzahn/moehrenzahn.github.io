# Flyleaf

https://moehrenzahn.de/project/flyleaf/

By Max Melzer, flyleaf@moehrenzahn.de

## Description

Flyleaf is a “read-later” app that displays saved articles from the web in a meticulously designed reading view.

SAVE ARTICLES FROM THE WEB
Use the share sheet from anywhere to save interesting links to Flyleaf. There is also an easy-to-use bookmarklet if you need it.

READ LATER WITHOUT DISTRACTIONS
Flyleaf takes web pages and removes everything inessential, like popups, ads and trackers, to preserve your privacy and sanity.

TURN WEBSITES INTO MAGAZINE ARTICLES
With Flyleaf's best-in-class book-like pagination, you can read articles page by page instead of scrolling vertically.

READ IT YOUR WAY
Flyleaf offers many ways to customize your reading experience, such as color themes and in-depth typography settings.

DISCOVER WHAT TO READ NEXT 
Once your list of saved articles grows, it's easy to loose track. Flyleaf helps you to always discover fresh articles from your list.

SYNC WITH ICLOUD
Flyleaf uses iCloud to securely sync articles and reading progress between your devices – no additional signups needed.

STAY ORGANIZED WITH TAGS
You can add your own tags to articles to organize your library.

READ ANYWHERE YOU GO
Enjoy fully native apps for iPhone, iPad, and macOS, lovingly crafted by indie developer Max Melzer.

READ IN FULL SCREEN 
Remove all distractions and focus on the text by entering fullscreen mode. You can still access all the controls you need through an intuitive gesture interface.

LOAD ARTICLES FROM ARCHIVE.TODAY IN ONE TAP 
Sometimes, an article may not be available in your region or without logging in. Flyleaf lets you effortlessly access many of them from a web archive instead.

AUTOMATE ACTIONS WITH SHORTCUTS AND SIRI
Flyleaf offers a comprehensive list of Shortcuts actions, so you can add URLs via Siri or build Shortcuts to automatically tag articles.

Flyleaf is free to use and offers an optional subscription for advanced features such as themes, tags and the archive.today integration.